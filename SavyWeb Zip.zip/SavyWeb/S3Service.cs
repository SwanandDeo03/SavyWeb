﻿
internal class S3Service
{
    internal string GetPreSignedUrl(string fileName, int v)
    {
        throw new NotImplementedException();
    }

    internal void UploadFile(MemoryStream stream, string fileName)
    {
        throw new NotImplementedException();
    }
}