﻿namespace SavyWeb.Models
{
    public class SavyWeb
    {
    }
}